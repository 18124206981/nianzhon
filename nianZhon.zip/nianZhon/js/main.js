$(function () {
    //执行页面动画
    new WOW().init();
});